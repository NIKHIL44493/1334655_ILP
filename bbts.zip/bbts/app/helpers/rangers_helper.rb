module RangersHelper
end
