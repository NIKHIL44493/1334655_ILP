class RangersController < ApplicationController
  def racers
  end
end
