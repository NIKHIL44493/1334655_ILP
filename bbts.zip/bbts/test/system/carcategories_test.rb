require "application_system_test_case"

class CarcategoriesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit carcategories_url
  #
  #   assert_selector "h1", text: "Carcategory"
  # end
end
