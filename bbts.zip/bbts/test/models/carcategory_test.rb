require 'test_helper'

class CarcategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
